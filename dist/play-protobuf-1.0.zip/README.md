# Play-Protobuf

This plugin allows you to use protocol buffer types as arguments of your controllers' methods.

